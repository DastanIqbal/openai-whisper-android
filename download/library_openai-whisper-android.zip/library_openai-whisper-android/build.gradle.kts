configurations.maybeCreate("default")
artifacts.add("default", file("openai-whisper-android.aar"))