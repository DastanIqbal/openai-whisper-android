#ifndef TESTS_OPTIONAL_SCALARS_TEST_H
#define TESTS_OPTIONAL_SCALARS_TEST_H


namespace flatbuffers {
namespace tests {

void OptionalScalarsTest();

}  // namespace tests
}  // namespace flatbuffers

#endif
