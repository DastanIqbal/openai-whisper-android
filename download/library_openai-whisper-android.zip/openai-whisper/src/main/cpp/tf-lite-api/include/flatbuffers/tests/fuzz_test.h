#ifndef TESTS_FUZZ_TEST_H
#define TESTS_FUZZ_TEST_H

namespace flatbuffers {
namespace tests {

void FuzzTest1();
void FuzzTest2();

}  // namespace tests
}  // namespace flatbuffers

#endif
