#ifndef TESTS_ALIGNMENT_TEST_H
#define TESTS_ALIGNMENT_TEST_H

namespace flatbuffers {
namespace tests {

void AlignmentTest();

}  // namespace tests
}  // namespace flatbuffers

#endif
