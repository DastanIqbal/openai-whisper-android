export const SIZEOF_SHORT = 2;
export const SIZEOF_INT = 4;
export const FILE_IDENTIFIER_LENGTH = 4;
export const SIZE_PREFIX_LENGTH = 4;